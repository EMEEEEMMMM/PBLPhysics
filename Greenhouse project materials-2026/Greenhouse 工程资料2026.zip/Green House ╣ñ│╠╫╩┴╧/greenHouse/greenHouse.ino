#define atomizerPin 3                               // 定义引脚
#define fanPin 2

#include <Wire.h>                                   // 导入库文件
#include <U8g2lib.h>
#include "SparkFun_SCD4x_Arduino_Library.h"

SCD4x mySensor;                                     //定义温传感器
U8G2_SSD1306_128X64_NONAME_F_4W_SW_SPI u8g2(U8G2_R0, /* clock=*/ 13, /* data=*/ 11, /* cs=*/ 10, /* dc=*/ 9, /* reset=*/ 8);    // 定义OLED屏

void setup() {                                      // 初始化程序
  pinMode(atomizerPin,OUTPUT);                      // 设置引脚模式
  pinMode(fanPin,OUTPUT);
  digitalWrite(atomizerPin,LOW);                    // 初始状态确保雾化器与风扇关闭
  digitalWrite(fanPin,LOW);
  
  Serial.begin(115200);
  
  Serial.println(F("SCD4x Example"));
  Wire.begin();

  //mySensor.enableDebugging(); // Uncomment this line to get helpful debug messages on Serial

  //.begin will start periodic measurements for us (see the later examples for details on how to override this)
  if (mySensor.begin() == false)
  {
    Serial.println(F("Sensor not detected. Please check wiring. Freezing..."));
    while (1)
      ;
  }
  u8g2.begin();
  u8g2.setDisplayRotation(U8G2_R2);                     // 屏幕显示旋转180度
}

int co2 = 0;
float temperature = 100;
float humidity = 100;
bool flag = 0;                                          // 表征目前雾化器与风扇开关状态
bool last_flag = 0;                                     // 表征上一时刻雾化器与风扇开关状态

void loop() {                                           // 主循环程序
  u8g2.clearBuffer();                                   // 清除内存
  u8g2.setFont(u8g2_font_open_iconic_gui_2x_t);         // 切换icon库
  u8g2.drawGlyph(5, 18, 73 );                           // 显示icon
  u8g2.setFont(u8g2_font_open_iconic_thing_2x_t);
  u8g2.drawGlyph(5, 38, 78 );
  u8g2.setFont(u8g2_font_open_iconic_thing_2x_t);
  u8g2.drawGlyph(5, 58, 72 );
  u8g2.setFont(u8g2_font_ncenB08_tr);                   // 切换文字字体
  u8g2.drawStr(25,15,"CO2:");                           // 显示固定文字内容
  u8g2.drawStr(25,35,"Temp:");
  u8g2.drawStr(25,55,"Humi:");
  u8g2.drawStr(95,15,"ppm");
  u8g2.drawStr(95,35,"C");
  u8g2.drawStr(95,55,"%RH");
  
  if (mySensor.readMeasurement())                       // readMeasurement will return true when fresh data is available
  {
    Serial.println();
    co2 = mySensor.getCO2();                            // 读取传感器数值（二氧化碳、温度、湿度）
    temperature = mySensor.getTemperature();            
    humidity = mySensor.getHumidity();

    Serial.print(F("CO2(ppm):"));
    Serial.print(co2);
    u8g2.setCursor(65,15);                              // 显示二氧化碳数据
    u8g2.print(co2);
    
    Serial.print(F("\tTemperature(C):"));
    Serial.print(temperature, 1);
    u8g2.setCursor(65,35);                              // 显示温度数据
    u8g2.print(temperature);
    
    Serial.print(F("\tHumidity(%RH):"));
    Serial.print(humidity, 1);
    Serial.println();
    u8g2.setCursor(65,55);                              // 显示湿度数据
    u8g2.print(humidity);

    u8g2.sendBuffer();                                  // transfer internal memory to the display，更新显示
  }

  flag = humidity < 80 ? 1 : 0;                         // 当湿度小于80时，设置目标状态为1
  if(flag != last_flag){                                
    if(flag == 1){                                      // 雾化器应从关闭变为打开时
      digitalWrite(atomizerPin,HIGH);                   // 打开雾化器
      delay(200);
      digitalWrite(atomizerPin,LOW);
      delay(200);
      digitalWrite(fanPin,HIGH);                        // 打开风扇
    }else{                                              // 雾化器与风扇应从打开变为关闭时
      digitalWrite(atomizerPin,HIGH);                   // 关闭雾化器
      delay(200);
      digitalWrite(atomizerPin,LOW);
      delay(200);
      digitalWrite(atomizerPin,HIGH);
      delay(200);
      digitalWrite(atomizerPin,LOW);
      delay(200);
      digitalWrite(fanPin,LOW);                         // 关闭风扇
    }
  }
  
  last_flag = flag;
  delay(1000);
}
